function setup() {
  createCanvas(600, 700);
}

function draw() {
  background(255, 133, 96);
  fill(245, 252, 111);
  textSize(30)
  text("THE END!", 300, 50)
  textSize(80)
  text("~ - . - ~", 245, 120)
  textSize(30)
  text("Congradulations! You have successfully", 75, 190);
  text("collected ITEM NAME", 220,220);
  text("Your friend is very thankful, and the", 130, 250);
  text("adventure seems worth it after seeing", 97 ,280);
  text("their happy expression!", 222, 310);
}