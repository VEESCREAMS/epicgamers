function setup() {
  createCanvas(600, 700);
}


//first question

var l1 = function(){
  background(2, 255, 40);
  
  strokeWeight(3)
    fill(255, 249, 127);
      ellipse(60, 260, 60, 90);
    fill(15, 133, 1);
      ellipse(180, 260, 50, 50);
    fill(255, 249, 127);
      ellipse(300, 260, 60, 90);
    fill(15, 133, 1);
      ellipse(420, 260, 50, 50);
    strokeWeight(9);
      line(570, 260, 500, 260);
  
  // text
  textSize(25);
    fill(1, 59, 16)
      text("What shape should be in the place of the line?", 50, 350);
  textSize(20)
      text("Click '1' for the first, '2' for the middle, and '3' for the last one", 37, 400);
  
  //possible answers
  strokeWeight(3);
    fill(120, 133, 1);
      ellipse(180, 480, 90, 30);
  
    fill(255, 249, 127);
      ellipse(420, 480, 60, 90);
}



//second question

var l2 = function (){
    background(2, 255, 40);
  
  strokeWeight(3)
    fill(184, 255, 97);
      ellipse(60, 260, 90, 90);
    fill(15, 133, 1);
      ellipse(180, 260, 50, 50);
    fill(143, 148, 4);
      ellipse(300, 260, 40, 70);
    fill(184, 255, 97);
      ellipse(420, 260, 90, 90);
    strokeWeight(9);
      line(570, 260, 500, 260);
  
  // text
  textSize(25);
    fill(1, 59, 16)
      text("What shape should be in the place of the line?", 50, 350);
  textSize(20)
      text("Click '1' for the first, '2' for the middle, and '3' for the last one", 37, 400);
  
  //possible answers
  strokeWeight(3);
    fill(120, 133, 1);
      ellipse(180, 480, 40, 70);
  
    fill(15, 133, 1);
      ellipse(420, 480, 50, 50);
  }




//third question

var l3 = function (){
    background(2, 255, 40);
  
  strokeWeight(3)
    fill(2, 199, 88);
      ellipse(60, 260, 70, 70);
    fill(60, 150, 4);
      ellipse(180, 260, 50, 50);
    fill(143, 148, 4);
      ellipse(300, 260, 70, 70);
    fill(2, 199, 88);
      ellipse(420, 260, 70, 70);
    strokeWeight(9);
      line(570, 260, 500, 260);
  
  // text
  textSize(25);
    fill(1, 59, 16)
      text("What shape should be in the place of the line?", 50, 350);
  textSize(20)
      text("Click '1' for the first, '2' for the middle, and '3' for the last one", 37, 400);
  
  //possible answers
  strokeWeight(3);
    fill(120, 133, 1);
      ellipse(180, 480, 50, 50);
  
    fill(15, 133, 1);
      ellipse(420, 480, 50, 50);
  }


//fourth question

var l4 = function (){
    background(2, 255, 40);
  
  strokeWeight(3)
    fill(142, 255, 44);
      ellipse(60, 260, 90, 70);
    fill(54, 128, 2);
      ellipse(157, 260, 50, 50);
    fill(143, 148, 4);
      ellipse(250, 260, 90, 70);
    fill(2, 199, 88);
      ellipse(338, 260, 50, 50);
    fill(142, 255, 44);
      ellipse(428, 260, 90, 70);
    strokeWeight(9);
      line(560, 260, 500, 260);
  
  // text
  textSize(25);
    fill(1, 59, 16)
      text("What shape should be in the place of the line?", 50, 350);
  textSize(20)
      text("Click '1' for the first, '2' for the middle, and '3' for the last one", 37, 400);
  
  //possible answers
  strokeWeight(3);
    fill(54, 128, 2);
      ellipse(180, 480, 50, 50);
  
    fill(10, 80, 20);
      ellipse(300, 480, 60, 50);
  
    fill(15, 133, 1);
      ellipse(420, 480, 50, 80);
  
  }


//fifth question

var l5 = function (){
    background(2, 255, 40);
  
  strokeWeight(3)
    fill(142, 255, 44);
      ellipse(60, 260, 90, 50);
    fill(2, 199, 88);
      ellipse(157, 260, 50, 50);
    fill(142, 255, 44);
      ellipse(250, 260, 40, 90);
    fill(2, 199, 88);
      ellipse(338, 260, 50, 50);
    fill(142, 255, 44);
      ellipse(428, 260, 90, 50);
    strokeWeight(9);
      line(560, 260, 500, 260);
  
  // text
  textSize(25);
    fill(1, 59, 16)
      text("What shape should be in the place of the line?", 50, 350);
  textSize(20)
      text("Click '1' for the first, '2' for the middle, and '3' for the last one", 37, 400);
  
  //possible answers
  strokeWeight(3);
    fill(54, 128, 2);
      ellipse(180, 480, 50, 25);
  
    fill(2, 199, 88);
      ellipse(300, 480, 50, 50);
  
    fill(15, 133, 1);
      ellipse(420, 480, 50, 80);
  
  }



//sixth question

var l6 = function (){
    background(2, 255, 40);
  
  strokeWeight(3)
    fill(142, 255, 44);
      ellipse(60, 260, 90, 40);
    fill(54, 128, 2);
      ellipse(157, 260, 50, 50);
    fill(143, 148, 4);
      ellipse(250, 260, 90, 90);
    fill(54, 128, 2);
      ellipse(338, 260, 50, 50);
    fill(142, 255, 44);
      ellipse(428, 260, 90, 40);
    strokeWeight(9);
      line(560, 260, 500, 260);
  
  // text
  textSize(25);
    fill(1, 59, 16)
      text("What shape should be in the place of the line?", 50, 350);
  textSize(20)
      text("Click '1' for the first, '2' for the middle, and '3' for the last one", 37, 400);
  
  //possible answers
  strokeWeight(3);
    fill(142, 255, 44);
      ellipse(180, 480, 90, 40);

    fill(15, 133, 1);
      ellipse(420, 480, 50, 50);
  
  }


//seventh question

var l7 = function (){
    background(2, 255, 40);
  
  strokeWeight(3)
    fill(30, 214, 101);
      ellipse(60, 260, 90, 70);
    fill(30, 214, 101);
      ellipse(157, 260, 50, 50);
    fill(30, 214, 101);
      ellipse(250, 260, 90, 70);
    fill(30, 214, 101);
      ellipse(338, 260, 50, 50);
    fill(30, 214, 101);
      ellipse(428, 260, 90, 70);
    strokeWeight(9);
      line(560, 260, 500, 260);
  
  // text
  textSize(25);
    fill(1, 59, 16)
      text("What shape should be in the place of the line?", 50, 350);
  textSize(20)
      text("Click '1' for the first, '2' for the middle, and '3' for the last one", 37, 400);
  
  //possible answers
  strokeWeight(3);
    fill(142, 255, 44);
      ellipse(180, 480, 90, 40);

    fill(30, 214, 101);
      ellipse(420, 480, 50, 50);
  
  }

//eight/last question

var l8 = function(){
  background(2, 255, 40);
  
  strokeWeight(3)
    fill(135, 219, 0);
      ellipse(60, 260, 60, 40);
    fill(15, 133, 1);
      ellipse(180, 260, 30, 60);
    fill(135, 219, 0);
      ellipse(300, 260, 60, 40);
    fill(15, 133, 1);
      ellipse(420, 260, 30, 60);
    strokeWeight(9);
      line(570, 260, 500, 260);
  
  // text
  textSize(25);
    fill(1, 59, 16)
      text("What shape should be in the place of the line?", 50, 350);
  textSize(20)
      text("Click '1' for the first, '2' for the middle, and '3' for the last one", 37, 400);
  
  //possible answers
  strokeWeight(3);
    fill(135, 219, 0);
      ellipse(180, 480, 10, 90);
  
    fill(135, 219, 0);
      ellipse(420, 480, 60, 40);
}


var cs = function(){
  background(2, 255, 40);
  textSize(20)
    text("Congrats! You have passed the Town!", 120, 140);
  text("After a long journey through it! You are now headed towards", 30, 180);
    text("[NEXT BACKGROUND], and you hope you'll have an easy time", 20, 220);
  text("there and find what you came this way for.", 100, 260);
  strokeWeight(10);
    stroke(255, 144, 33);
      line(0, 350, 800, 300);
  
    strokeWeight(10);
    stroke(255, 144, 33);
      line(0, 400, 800, 350);
}

//make questions show

  function keyPressed(){
   if (key === 'c') {
     cs();
   }
}


//l1 is level 1, l2 level 2, l3 level 3, l4 level 4, l5 level 5, l6 level 6, l7 level 7, l8 level 8, cs is the scene you get when you succeed at the very end when u do all the 8 patterns levels